// Generated Permissions Map based on MetaBuilder Roles
export const PERMISSIONS_MAP = {
  "downloads": {
    "blockedRoles": [],
    "allowedRoles": [],
    "isDefaultBlocked": false
  },
  "automations": {
    "blockedRoles": [],
    "allowedRoles": [
      "45b43923-29fd-44d1-9b4f-dc886e41cbcd"
    ],
    "isDefaultBlocked": true
  },
  "clientes": {
    "blockedRoles": [],
    "allowedRoles": [],
    "isDefaultBlocked": false
  },
  "tarefas": {
    "blockedRoles": [],
    "allowedRoles": [],
    "isDefaultBlocked": false
  },
  "pedidos": {
    "blockedRoles": [],
    "allowedRoles": [],
    "isDefaultBlocked": false
  },
  "projetos": {
    "blockedRoles": [],
    "allowedRoles": [],
    "isDefaultBlocked": false
  },
  "tarefas-blueprint": {
    "blockedRoles": [],
    "allowedRoles": [],
    "isDefaultBlocked": false
  },
  "entregas": {
    "blockedRoles": [],
    "allowedRoles": [],
    "isDefaultBlocked": false
  },
  "produtos": {
    "blockedRoles": [],
    "allowedRoles": [],
    "isDefaultBlocked": false
  },
  "empresa": {
    "blockedRoles": [],
    "allowedRoles": [],
    "isDefaultBlocked": false
  }
};

export function hasViewAccess(viewSlug: string, roleId: string | null): boolean {
  if (!roleId) return false; // Sem role não acessa nada
  const conf = PERMISSIONS_MAP[viewSlug as keyof typeof PERMISSIONS_MAP];
  if (!conf) return true; // Se não tem config, o default é liberado
  
  if (conf.isDefaultBlocked) {
    return conf.allowedRoles.includes(roleId);
  } else {
    return !conf.blockedRoles.includes(roleId);
  }
}
