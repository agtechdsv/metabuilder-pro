
import projectConfig from '@/config/project.json'
import { DynamicDashboard } from '@/components/runtime/DynamicDashboard'

export default function Home() {
  return (
    <div className="flex-1 overflow-y-auto">
      <DynamicDashboard 
        items={(projectConfig.navigation as any) || []}
        workspaceSlug="export"
        projectSlug="export"
        title="Dashboard"
        subtitle="Bem-vindo ao sistema"
        icon="LayoutDashboard"
        breadcrumbs={[]}
        baseNavUrl=""
      />
    </div>
  )
}
