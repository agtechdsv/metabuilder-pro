'use client'

import React, { Suspense } from 'react'
import { RuntimeLayoutClient } from '@/components/runtime/RuntimeLayoutClient'
import projectConfig from '@/config/project.json'

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  return (
    <Suspense fallback={null}>
      <RuntimeLayoutClient 
        workspaceSlug="export"
        projectSlug="export"
        project={projectConfig as any}
        navigation={(projectConfig.navigation as any) || []}
        baseNavUrl=""
        isNoAuth={false}
      >
        {children}
      </RuntimeLayoutClient>
    </Suspense>
  )
}
