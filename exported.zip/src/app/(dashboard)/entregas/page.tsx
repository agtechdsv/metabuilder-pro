'use client'

import React, { Suspense } from 'react'
import ViewPageContent from '@/components/runtime/ViewPageContent'
import viewConfig from '@/config/views/entregas.json'
import projectConfig from '@/config/project.json'
import { PermissionGuard } from '@/components/auth/PermissionGuard'

export default function entregasPage() {
  return (
    <PermissionGuard viewSlug="entregas">
      <div className="flex-1 w-full h-full relative">
        <Suspense fallback={null}>
          <ViewPageContent 
            {...(viewConfig as any)}
            viewId="a5066428-1d22-42b6-bc2b-c6eb136977d0"
            workspace={{ slug: 'export' }}
            project={projectConfig}
            locale="pt"
            baseUrl=""
          />
        </Suspense>
      </div>
    </PermissionGuard>
  )
}
