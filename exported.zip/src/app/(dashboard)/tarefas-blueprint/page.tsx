'use client'

import React, { Suspense } from 'react'
import ViewPageContent from '@/components/runtime/ViewPageContent'
import viewConfig from '@/config/views/tarefas-blueprint.json'
import projectConfig from '@/config/project.json'
import { PermissionGuard } from '@/components/auth/PermissionGuard'

export default function tarefasblueprintPage() {
  return (
    <PermissionGuard viewSlug="tarefas-blueprint">
      <div className="flex-1 w-full h-full relative">
        <Suspense fallback={null}>
          <ViewPageContent 
            {...(viewConfig as any)}
            viewId="bd509de7-15fa-432c-b50d-0a0f429969ff"
            workspace={{ slug: 'export' }}
            project={projectConfig}
            locale="pt"
            baseUrl=""
          />
        </Suspense>
      </div>
    </PermissionGuard>
  )
}
