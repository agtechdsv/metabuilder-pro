'use client'

import React, { Suspense } from 'react'
import ViewPageContent from '@/components/runtime/ViewPageContent'
import viewConfig from '@/config/views/projetos.json'
import projectConfig from '@/config/project.json'
import { PermissionGuard } from '@/components/auth/PermissionGuard'

export default function projetosPage() {
  return (
    <PermissionGuard viewSlug="projetos">
      <div className="flex-1 w-full h-full relative">
        <Suspense fallback={null}>
          <ViewPageContent 
            {...(viewConfig as any)}
            viewId="856778c6-a342-41c7-8461-dee7ea243927"
            workspace={{ slug: 'export' }}
            project={projectConfig}
            locale="pt"
            baseUrl=""
          />
        </Suspense>
      </div>
    </PermissionGuard>
  )
}
