'use client'

import React from 'react'
import { LoginPortalClient } from '@/components/auth/LoginPortalClient'
import projectConfig from '@/config/project.json'
import { CustomThemeProvider } from '@/components/CustomThemeProvider'

export default function LoginPage() {
  const visual = (projectConfig.theme_config as any)?.ui_config || {}
  const auth = {
    allow_signup: visual.allow_signup || false,
    auth_type: (projectConfig as any).auth_type || 'none',
  }

  return (
    <div className="flex-1 min-h-screen bg-slate-50 dark:bg-[#050505]">
      <LoginPortalClient 
        project={projectConfig}
        workspaceSlug="export"
        projectSlug="export"
        locale="pt"
        visualConfig={visual}
        authConfig={auth}
      />
    </div>
  )
}
