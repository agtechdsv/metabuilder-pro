import { NextResponse } from 'next/server'
import fs from 'fs'
import path from 'path'

function getDownloadPath() {
  if (process.env.LOCAL_DOWNLOAD_PATH) {
    return process.env.LOCAL_DOWNLOAD_PATH
  }
  return path.join(process.cwd(), 'downloads')
}

export async function GET(request: Request) {
  try {
    const url = new URL(request.url)
    const fileName = url.searchParams.get('file')
    if (!fileName) return new NextResponse('File not specified', { status: 400 })

    const downloadPath = getDownloadPath()
    const filePath = path.join(downloadPath, fileName)

    if (!fs.existsSync(filePath)) {
      return new NextResponse('File not found', { status: 404 })
    }

    const fileBuffer = fs.readFileSync(filePath)
    
    return new NextResponse(fileBuffer, {
      headers: {
        'Content-Disposition': `attachment; filename="${fileName}"`,
        'Content-Type': 'application/octet-stream',
      }
    })
  } catch (e: any) {
    return new NextResponse('Internal error', { status: 500 })
  }
}
