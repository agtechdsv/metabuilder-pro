import { NextResponse } from 'next/server'
import enumerations from '@/config/enumerations.json'

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const id = searchParams.get('id')

  if (!id) {
    return NextResponse.json({ error: 'Missing id parameter' }, { status: 400 })
  }

  const enumData = (enumerations as any[]).find(e => e.id === id)

  if (!enumData) {
    return NextResponse.json({ error: 'Enumeration not found' }, { status: 404 })
  }

  return NextResponse.json({ data: enumData })
}
