import { NextResponse } from 'next/server'
import fs from 'fs'
import path from 'path'

// Em ambiente standalone, o Gerenciador de Downloads lê a pasta configurada
function getDownloadPath() {
  if (process.env.LOCAL_DOWNLOAD_PATH) {
    return process.env.LOCAL_DOWNLOAD_PATH
  }
  return path.join(process.cwd(), 'downloads')
}

export async function GET(request: Request) {
  try {
    const downloadPath = getDownloadPath()
    if (!fs.existsSync(downloadPath)) {
      return NextResponse.json({ jobs: [] })
    }
    
    const files = fs.readdirSync(downloadPath)
    const jobs = files.map((file, idx) => ({
      id: `job-${idx}`,
      file_name: file,
      file_type: path.extname(file).replace('.', ''),
      status: 'completed',
      progress: 100,
      created_at: fs.statSync(path.join(downloadPath, file)).mtime.toISOString(),
      file_url: `/api/download?file=${encodeURIComponent(file)}`
    }))
    
    return NextResponse.json({ jobs })
  } catch (e: any) {
    return NextResponse.json({ jobs: [] })
  }
}

export async function POST(request: Request) {
  return NextResponse.json({ success: true, jobId: 'standalone-job', message: 'Exportação encaminhada para o agente local.' }, { status: 202 })
}

export async function DELETE(request: Request) {
  return NextResponse.json({ success: true })
}
