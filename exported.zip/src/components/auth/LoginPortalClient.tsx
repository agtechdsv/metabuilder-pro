'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { createClient } from '@/utils/supabase/client'
import { LayoutTemplate, AlertCircle, Loader2, Eye, EyeOff, Fingerprint, ArrowLeft } from 'lucide-react'
import { HeaderActions } from '@/components/layout/HeaderActions'
import { LoginPortalThemeWrapper } from '@/components/auth/LoginPortalThemeWrapper'
import { TranslationProvider } from '@/i18n/TranslationProvider'
import { useI18n } from '@/i18n/I18nContext'
import { EndUserMfaModal } from '@/components/auth/EndUserMfaModal'
import { startAuthentication } from '@simplewebauthn/browser'

interface LoginPortalClientProps {
  project: any
  authConfig: any
  visualConfig: any
  locale: string
  workspaceSlug: string
  projectSlug: string
  schemaName?: string
  isCustomDomain?: boolean
  customDomainType?: string
}

export function LoginPortalClient({
  project,
  authConfig,
  visualConfig,
  locale,
  workspaceSlug,
  projectSlug,
  schemaName,
  isCustomDomain,
  customDomainType
}: LoginPortalClientProps) {
  const router = useRouter()
  const supabase = createClient()
  const { t } = useI18n()

  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [isLoadingBio, setIsLoadingBio] = useState(false)
  const [errorMsg, setErrorMsg] = useState<string | null>(null)
  const [showMfaModal, setShowMfaModal] = useState(false)
  const [pendingMfaUser, setPendingMfaUser] = useState<any>(null)

  // Pre-load theme styles
  const theme = visualConfig.theme || 'dark'
  const title = visualConfig.welcome_title || `Acessar ${project.name}`
  const subtitle = visualConfig.welcome_desc || 'Insira suas credenciais para continuar.'
  const userLabel = visualConfig.email_label || 'Usuário'
  const userPlaceholder = visualConfig.email_placeholder || 'seu@email.com'
  const passLabel = visualConfig.password_label || 'Senha'
  const passPlaceholder = visualConfig.password_placeholder || '••••••••'
  const buttonText = visualConfig.button_text || 'Entrar no Sistema'
  const buttonColor = visualConfig.button_color || '#4F46E5'
  const allowSignup = visualConfig.allow_signup || false
  const workspaceTheme = Array.isArray(project.workspaces) ? project.workspaces[0]?.theme_config : (project.workspaces as any)?.theme_config;
  const loginLogoUrl = project.theme_config?.login_logo_url || workspaceTheme?.portal_logo_url || ''
  const loginBannerUrl = project.theme_config?.login_banner_url || workspaceTheme?.portal_banner_url || ''
  const hasBanner = !!loginBannerUrl

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!email || !password) return

    setIsLoading(true)
    setErrorMsg(null)

    try {
        const { data, error } = await supabase.auth.signInWithPassword({ email, password })
        if (error) throw error
        if (data?.user) finalizeLogin(data.user)
      } catch (err: any) {
      cleanup()
      setErrorMsg(t('runtime.auth_unexpected_error', 'Erro inesperado ao realizar autenticação.'))
      setIsLoading(false)
    }
  }

  const handlePasskeyLogin = async () => {
    try {
      setIsLoadingBio(true)
      setErrorMsg(null)

      const optionsRes = await fetch('/api/auth/end-user/passkeys/authenticate/generate-options', {
        method: 'POST',
      })
      const options = await optionsRes.json()

      if (options.error) throw new Error(options.error)

      let attResp;
      try {
        attResp = await startAuthentication(options)
      } catch (e: any) {
        if (e.name === 'NotAllowedError') {
          setIsLoadingBio(false)
          return // User cancelled
        }
        throw e
      }

      const verifyRes = await fetch('/api/auth/end-user/passkeys/authenticate/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...attResp,
          projectId: project.id
        })
      })

      const verification = await verifyRes.json()
      if (verification.error) throw new Error(verification.error)
      
      const { data: { user }, error } = await supabase.auth.getUser()
        if (error || !user) throw new Error('Sessão inválida após biometria')
        finalizeLogin(user)
      } catch (err: any) {
      setErrorMsg(t('runtime.biometric_auth_error', 'Erro na autenticação biométrica.'))
      setIsLoadingBio(false)
    }
  }

  const finalizeLogin = (user: any) => {
    // Salva o cookie de sessão para o projeto
    const cookieName = `client_session_${project.id}`
    document.cookie = `${cookieName}=${encodeURIComponent(JSON.stringify(user))}; path=/; max-age=86400; SameSite=Lax`
    
    // Redireciona para o portal principal
    if (isCustomDomain && customDomainType === 'workspace') {
      window.location.href = `/${projectSlug}`
    } else if (isCustomDomain) {
      window.location.href = `/`
    } else {
      window.location.href = `/${workspaceSlug}/${projectSlug}`
    }
  }
  
  return (
    <TranslationProvider locale={locale}>
      <LoginPortalThemeWrapper theme={theme}>
        <div className={`min-h-screen flex transition-colors duration-500 bg-neutral-50 dark:bg-[#050505] relative ${hasBanner ? 'flex-row' : 'flex-col'}`}>
          {/* Header Actions - Always visible, absolute positioned */}
          <div className="absolute top-6 right-6 z-[100]">
            <HeaderActions hideUser />
          </div>

          {/* Left side (Form) */}
          <div className={`flex flex-col flex-1 relative ${hasBanner ? 'max-w-[600px] xl:max-w-[700px]' : ''}`}>
            <header className="p-6 flex justify-between items-center relative z-10">
              <div className="flex items-center gap-3">
                {loginLogoUrl ? (
                  <img src={loginLogoUrl} alt={project.name} className="h-8 w-auto object-contain" />
                ) : (
                  <>
                    <div className="w-10 h-10 rounded-xl flex items-center justify-center border transition-colors overflow-hidden bg-white dark:bg-neutral-900 border-neutral-200 dark:border-neutral-800">
                      {visualConfig.brand_icon || visualConfig.icon_svg ? (
                        <div dangerouslySetInnerHTML={{ __html: visualConfig.brand_icon || visualConfig.icon_svg }} className="w-6 h-6 flex items-center justify-center" />
                      ) : (
                        <LayoutTemplate className="w-6 h-6 text-neutral-400 dark:text-neutral-500" />
                      )}
                    </div>
                    <span className="text-sm font-bold tracking-tight text-neutral-900 dark:text-white">
                      {project.name}
                    </span>
                  </>
                )}
              </div>
            </header>

            <main className="flex-1 flex flex-col items-center justify-center p-6 lg:p-12 relative w-full">
              {!hasBanner && (
                <div className="absolute inset-0 overflow-hidden pointer-events-none opacity-0 dark:opacity-100 transition-opacity duration-1000">
                  <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-indigo-500/10 blur-[120px] rounded-full" />
                  <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-blue-500/10 blur-[120px] rounded-full" />
                </div>
              )}

              <div className={`w-full max-w-sm ${!hasBanner ? 'rounded-[2.5rem] p-10 md:p-12 shadow-2xl border bg-white dark:bg-neutral-950 border-neutral-200 dark:border-neutral-800' : ''} transition-all duration-500 relative z-10`}>
                
                {/* Custom Icon when no Logo URL */}
                {!loginLogoUrl && !hasBanner && (
                  <div className="mb-8 flex justify-center">
                    <div className="w-16 h-16 rounded-2xl bg-indigo-500/5 dark:bg-indigo-500/10 flex items-center justify-center border border-indigo-500/10 dark:border-indigo-500/20 text-indigo-600 dark:text-indigo-400">
                      {visualConfig.brand_icon || visualConfig.icon_svg ? (
                        <div dangerouslySetInnerHTML={{ __html: visualConfig.brand_icon || visualConfig.icon_svg }} className="w-10 h-10 flex items-center justify-center [&>svg]:w-full [&>svg]:h-full" />
                      ) : (
                        <LayoutTemplate className="w-8 h-8" />
                      )}
                    </div>
                  </div>
                )}
                {hasBanner && loginLogoUrl && (
                  <div className="mb-8 hidden lg:flex justify-start">
                    <img src={loginLogoUrl} alt={project.name} className="h-10 w-auto object-contain" />
                  </div>
                )}

                <div className={`mb-10 ${hasBanner ? 'text-left' : 'text-center'}`}>
                  <h2 className="text-3xl font-bold mb-3 tracking-tight transition-colors text-neutral-900 dark:text-white">
                    {title}
                  </h2>
                  <p className="text-sm leading-relaxed transition-colors text-neutral-600 dark:text-neutral-500">
                    {subtitle}
                  </p>
                </div>


              {errorMsg && (
                <div className="mb-6 p-4 bg-red-500/10 border border-red-500/20 rounded-2xl flex items-start gap-3 animate-in fade-in slide-in-from-top-2">
                  <AlertCircle className="w-5 h-5 text-red-500 shrink-0 mt-0.5" />
                  <p className="text-xs text-red-500/80 font-bold leading-relaxed">
                    {errorMsg}
                  </p>
                </div>
              )}

              <form onSubmit={handleSubmit} className="space-y-6">
                {project.theme_config?.security?.passkey_enabled && (
                  <button
                    type="button"
                    onClick={handlePasskeyLogin}
                    disabled={isLoadingBio}
                    className="w-full h-14 rounded-2xl bg-indigo-50 dark:bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 font-bold uppercase tracking-widest text-xs transition-all hover:bg-indigo-100 dark:hover:bg-indigo-500/20 active:scale-95 border border-indigo-100 dark:border-indigo-500/20 flex items-center justify-center gap-2 mb-6 shadow-sm"
                  >
                    {isLoadingBio ? <Loader2 className="w-5 h-5 animate-spin" /> : <><Fingerprint className="w-5 h-5" /> {t('runtime.login_with_biometrics', 'Entrar com Biometria')}</>}
                  </button>
                )}

                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase tracking-widest text-neutral-400 ml-1">
                    {userLabel}
                  </label>
                  <input
                    type="text"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder={userPlaceholder}
                    className="w-full h-12 px-5 rounded-2xl bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 outline-none focus:border-indigo-500 dark:focus:border-indigo-500 transition-all text-sm font-medium text-neutral-900 dark:text-white placeholder:text-neutral-400"
                  />
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between items-center px-1">
                    <label className="text-[10px] font-black uppercase tracking-widest text-neutral-400">
                      {passLabel}
                    </label>
                    <a href="#" className="text-[9px] font-bold text-indigo-600 hover:text-indigo-500 uppercase tracking-tighter">
                      {t('runtime.login_forgot_password')}
                    </a>
                  </div>
                  <div className="relative group">
                    <input
                      type={showPassword ? 'text' : 'password'}
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder={passPlaceholder}
                      className="w-full h-12 pl-5 pr-12 rounded-2xl bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 outline-none focus:border-indigo-500 dark:focus:border-indigo-500 transition-all text-sm font-medium text-neutral-900 dark:text-white placeholder:text-neutral-400"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-4 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-indigo-500 transition-colors"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full h-14 rounded-2xl text-white text-xs font-bold uppercase tracking-widest transition-all hover:brightness-110 active:scale-[0.98] shadow-xl flex items-center justify-center gap-2"
                  style={{
                    backgroundColor: buttonColor,
                    boxShadow: `0 10px 30px -10px ${buttonColor}66`
                  }}
                >
                  {isLoading ? (
                    <Loader2 className="w-5 h-5 animate-spin" />
                  ) : (
                    buttonText
                  )}
                </button>
              </form>

              {allowSignup && (
                <div className="mt-8 text-center">
                  <p className="text-[10px] font-bold text-neutral-500 uppercase tracking-widest">
                    {t('runtime.login_no_account')} <a href="#" className="text-indigo-600 hover:underline">{t('runtime.login_create_account')}</a>
                  </p>
                </div>
              )}

              
              {workspaceSlug && (
                <div className="mt-6 text-center border-t border-neutral-100 dark:border-neutral-800 pt-6">
                  <a 
                    href={`/${workspaceSlug}`}
                    className="text-[10px] font-bold text-neutral-500 hover:text-indigo-600 dark:text-neutral-400 dark:hover:text-indigo-400 uppercase tracking-widest transition-colors flex items-center justify-center gap-1.5"
                  >
                    <ArrowLeft className="w-3.5 h-3.5" />
                    Voltar ao Portal do Workspace
                  </a>
                </div>
              )}

              <div className="mt-10 flex flex-col items-center gap-4">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-px bg-neutral-100 dark:bg-neutral-800" />
                  <span className="text-[9px] font-black text-neutral-300 dark:text-neutral-700 uppercase tracking-widest">
                    {t('runtime.login_powered_by')}
                  </span>
                  <div className="w-8 h-px bg-neutral-100 dark:bg-neutral-800" />
                </div>
              </div>
            </div>
          </main>

          <footer className="p-8 text-center text-[10px] font-medium text-neutral-400 dark:text-neutral-600">
             © {new Date().getFullYear()} AGTech Innovation Lab. All rights reserved.
          </footer>
          </div>

          {/* Right side (Banner) */}
          {hasBanner && (
            <div className="hidden lg:flex flex-1 relative bg-neutral-900 overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent z-10" />
              <img 
                src={loginBannerUrl} 
                alt="Banner" 
                className="absolute inset-0 w-full h-full object-cover transition-transform duration-[10s] hover:scale-105"
              />
              <div className="absolute top-6 right-6 z-20">
                <HeaderActions hideUser hideTheme={theme !== 'auto'} />
              </div>
              <div className="absolute bottom-12 left-12 right-12 z-20 text-white">
                 <h3 className="text-4xl font-bold mb-4 text-white shadow-black drop-shadow-xl">{project.name}</h3>
                 <p className="text-lg text-white/90 max-w-xl shadow-black drop-shadow-md">{project.description || 'Acesse o sistema e gerencie suas informações com segurança.'}</p>
              </div>
            </div>
          )}
        </div>

        <EndUserMfaModal 
          isOpen={showMfaModal}
          user={pendingMfaUser}
          projectId={project.id}
          mfaRequired={project.theme_config?.security?.mfa_enabled}
          passkeyEnabled={project.theme_config?.security?.passkey_enabled}
          onSuccess={() => finalizeLogin(pendingMfaUser)}
          onCancel={() => setShowMfaModal(false)}
        />
      </LoginPortalThemeWrapper>
    </TranslationProvider>
  )
}

