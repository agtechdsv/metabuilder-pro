'use client'
import React, { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { hasViewAccess } from '@/config/permissions'

function useUserRole() {
  const [role, setRole] = useState<string | null | undefined>(undefined)
  useEffect(() => {
    const stored = localStorage.getItem('meta_user')
    if (stored) {
      try {
        const u = JSON.parse(stored)
        setRole(u.role_id || u.role || null)
      } catch(e) {
        setRole(null)
      }
    } else {
      setRole(null)
    }
  }, [])
  return role
}

export function PermissionGuard({ viewSlug, children }: { viewSlug: string, children: React.ReactNode }) {
  const roleId = useUserRole()
  const router = useRouter()

  if (roleId === undefined) return null

  if (!hasViewAccess(viewSlug, roleId)) {
    return (
      <div className="flex flex-col items-center justify-center h-full p-8 text-center space-y-4">
        <div className="w-16 h-16 rounded-full bg-rose-100 text-rose-600 flex items-center justify-center font-bold text-2xl">!</div>
        <h2 className="text-2xl font-bold text-rose-900">Acesso Restrito</h2>
        <p className="text-neutral-500 max-w-md">Seu perfil atual não possui permissões suficientes para visualizar esta tela.</p>
        <button onClick={() => router.push('/')} className="px-6 py-2.5 bg-neutral-900 text-white rounded-xl text-sm font-bold hover:bg-neutral-800 transition-colors">Voltar ao Início</button>
      </div>
    )
  }

  return <>{children}</>
}
