import React from 'react';
import { CheckCircle2, Clock, ArrowRight, Package, CheckCheck } from 'lucide-react';

export default function TimelineStatusVendas({ formData, value }: any) {
  // Pega o status real do banco vindo do formulário. 
  // Se não houver status (ex: cadastro novo), assume 'Novo'
const statusAtual = formData?.status_lead || 'Novo';

  // Peguei exatamente os status que vi na sua Imagem 1 !
  const etapas = [
    { nome: 'Novo', icone: Clock, cor: 'text-blue-500', bg: 'bg-blue-100' },
    { nome: 'Contactado', icone: ArrowRight, cor: 'text-amber-500', bg: 'bg-amber-100' },
    { nome: 'Em Negociação', icone: Package, cor: 'text-purple-500', bg: 'bg-purple-100' },
    { nome: 'Fechado Ganho', icone: CheckCheck, cor: 'text-emerald-500', bg: 'bg-emerald-100' }
  ];

  // Encontra qual é o passo atual
  const indiceAtual = etapas.findIndex(e => e.nome === statusAtual);

  return (
    <div className="w-full bg-white p-8 rounded-2xl border border-neutral-100 shadow-sm mb-6">
      <h3 className="text-xs font-black text-neutral-400 mb-8 uppercase tracking-widest">
        Jornada de Negociação
      </h3>
      
      <div className="flex items-center justify-between relative px-4">
        {/* Linha cinza de fundo conectando os passos */}
        <div className="absolute left-0 top-1/2 -translate-y-1/2 w-full h-1 bg-neutral-100 rounded-full z-0"></div>
        
        {/* Linha colorida de progresso */}
        <div 
          className="absolute left-0 top-1/2 -translate-y-1/2 h-1 bg-indigo-500 rounded-full z-0 transition-all duration-700 ease-in-out"
          style={{ width: `${Math.max(0, (indiceAtual / (etapas.length - 1)) * 100)}%` }}
        ></div>

        {/* Bolinhas das Etapas */}
        {etapas.map((etapa, index) => {
          const isPassado = index < indiceAtual;
          const isAtual = index === indiceAtual;
          const isFuturo = index > indiceAtual;
          
          const Icone = etapa.icone;

          return (
            <div key={etapa.nome} className="relative z-10 flex flex-col items-center gap-4">
              <div 
                className={`w-14 h-14 rounded-full flex items-center justify-center transition-all duration-300 shadow-sm
                  ${isAtual ? `${etapa.bg} ${etapa.cor} ring-8 ring-white scale-110` : ''}
                  ${isPassado ? 'bg-indigo-500 text-white' : ''}
                  ${isFuturo ? 'bg-white border-2 border-neutral-200 text-neutral-300' : ''}
                `}
              >
                {isPassado ? <CheckCircle2 className="w-7 h-7" /> : <Icone className="w-6 h-6" />}
              </div>
              <span className={`text-sm font-bold ${isAtual || isPassado ? 'text-neutral-800' : 'text-neutral-400'}`}>
                {etapa.nome}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
}
