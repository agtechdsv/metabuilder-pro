-- MetaBuilder Exported Schema

CREATE TABLE IF NOT EXISTS "__mb_logs" (
  "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  "table_name" TEXT,
  "session_id" TEXT,
  "row_count" TEXT,
  "created_at" TEXT NOT NULL,
  "metadata" TEXT,
  "action" TEXT,
  "message" TEXT,
  "duration_ms" TEXT,
  "type" TEXT NOT NULL,
  "sql_text" TEXT,
  "schema_name" TEXT,
  "created_at" TIMESTAMP WITH TIME ZONE DEFAULT NOW()

);

CREATE TABLE IF NOT EXISTS "projetos" (
  "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  "data_fim" TEXT,
  "gerente_id" TEXT,
  "percentual_conclusao" TEXT,
  "criado_em" TEXT,
  "cliente_id" TEXT,
  "data_inicio" TEXT,
  "nome" TEXT NOT NULL,
  "status" TEXT NOT NULL,
  "created_at" TIMESTAMP WITH TIME ZONE DEFAULT NOW()

);

CREATE TABLE IF NOT EXISTS "perfis" (
  "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  "criado_em" TEXT,
  "nome" TEXT NOT NULL,
  "descricao" TEXT,
  "created_at" TIMESTAMP WITH TIME ZONE DEFAULT NOW()

);

CREATE TABLE IF NOT EXISTS "itens_pedido" (
  "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  "criado_em" TEXT,
  "quantidade" TEXT NOT NULL,
  "produto_id" TEXT,
  "preco_unitario" TEXT NOT NULL,
  "pedido_id" TEXT,
  "created_at" TIMESTAMP WITH TIME ZONE DEFAULT NOW()

);

CREATE TABLE IF NOT EXISTS "pedidos" (
  "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  "cliente_id" TEXT,
  "criado_em" TEXT,
  "funcionario_id" TEXT,
  "data_pedido" TEXT,
  "status" TEXT NOT NULL,
  "created_at" TIMESTAMP WITH TIME ZONE DEFAULT NOW()

);

CREATE TABLE IF NOT EXISTS "departamentos" (
  "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  "criado_em" TEXT,
  "nome" TEXT NOT NULL,
  "created_at" TIMESTAMP WITH TIME ZONE DEFAULT NOW()

);

CREATE TABLE IF NOT EXISTS "produtos" (
  "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  "nome" TEXT NOT NULL,
  "descricao" TEXT,
  "url_imagem" TEXT,
  "criado_em" TEXT,
  "quantidade" TEXT NOT NULL,
  "categoria_id" TEXT,
  "preco_unitario" TEXT NOT NULL,
  "created_at" TIMESTAMP WITH TIME ZONE DEFAULT NOW()

);

CREATE TABLE IF NOT EXISTS "categorias_produtos" (
  "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  "nome" TEXT NOT NULL,
  "criado_em" TEXT,
  "created_at" TIMESTAMP WITH TIME ZONE DEFAULT NOW()

);

CREATE TABLE IF NOT EXISTS "clientes" (
  "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  "latitude" TEXT,
  "longitude" TEXT,
  "nome_empresa" TEXT NOT NULL,
  "email_contato" TEXT,
  "status_lead" TEXT NOT NULL,
  "criado_em" TEXT,
  "cnpj_cpf" TEXT,
  "created_at" TIMESTAMP WITH TIME ZONE DEFAULT NOW()

);

CREATE TABLE IF NOT EXISTS "tarefas" (
  "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  "projeto_id" TEXT,
  "responsavel_id" TEXT,
  "data_vencimento" TEXT,
  "criado_em" TEXT,
  "tarefa_antecessora_id" TEXT,
  "titulo" TEXT NOT NULL,
  "status" TEXT NOT NULL,
  "prioridade" TEXT NOT NULL,
  "created_at" TIMESTAMP WITH TIME ZONE DEFAULT NOW()

);

CREATE TABLE IF NOT EXISTS "funcionarios" (
  "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  "data_contratacao" TEXT NOT NULL,
  "nome" TEXT NOT NULL,
  "cargo" TEXT NOT NULL,
  "departamento_id" TEXT,
  "criado_em" TEXT,
  "email" TEXT NOT NULL,
  "created_at" TIMESTAMP WITH TIME ZONE DEFAULT NOW()

);

CREATE TABLE IF NOT EXISTS "perfis_usuarios" (
  "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  "usuario_id" TEXT NOT NULL,
  "atribuido_em" TEXT,
  "perfil_id" TEXT NOT NULL,
  "created_at" TIMESTAMP WITH TIME ZONE DEFAULT NOW()

);

CREATE TABLE IF NOT EXISTS "entregas" (
  "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  "pedido_id" TEXT,
  "motorista_id" TEXT,
  "lat_atual" TEXT,
  "lng_atual" TEXT,
  "data_estimada" TEXT,
  "criado_em" TEXT,
  "status" TEXT NOT NULL,
  "created_at" TIMESTAMP WITH TIME ZONE DEFAULT NOW()

);

CREATE TABLE IF NOT EXISTS "usuarios" (
  "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  "ativo" BOOLEAN,
  "criado_em" TEXT,
  "nome_completo" TEXT NOT NULL,
  "email" TEXT NOT NULL,
  "hash_senha" TEXT NOT NULL,
  "created_at" TIMESTAMP WITH TIME ZONE DEFAULT NOW()

);

